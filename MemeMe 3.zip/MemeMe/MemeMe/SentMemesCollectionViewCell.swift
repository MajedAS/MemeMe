//
//  SentMemesCollectionViewCell.swift
//  MemeMe
//
//  Created by Majed Sh on 12/18/18.
//  Copyright © 2018 Majed Sh. All rights reserved.
//

import Foundation
import UIKit

class SentMemesCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var memeImageView1: UIImageView!
    
}

